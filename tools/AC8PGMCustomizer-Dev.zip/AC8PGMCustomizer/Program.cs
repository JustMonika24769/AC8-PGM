using System.Diagnostics;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using UAssetAPI;
using UAssetAPI.ExportTypes;
using UAssetAPI.PropertyTypes.Objects;
using UAssetAPI.PropertyTypes.Structs;
using UAssetAPI.UnrealTypes;
using UAssetAPI.Unversioned;

namespace AC8PGMCustomizer;

internal static class Program
{
    private const string BaseName = "AC8PGMDirect_P";
    private const string PropertyName = "HomingForesightAmount";
    private const string PlayerTablePackage = "/Game/Datatables/PLAYER/DT_WeaponSettings";
    private const string EnemyTablePackage = "/Game/Datatables/AI/NPC/Weapon/DT_NPC_Weapon";
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        ReadCommentHandling = JsonCommentHandling.Skip,
        AllowTrailingCommas = true,
        WriteIndented = true
    };

    public static int Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        try
        {
            var root = FindRoot();
            var command = args.FirstOrDefault(x => !x.StartsWith("--", StringComparison.Ordinal))?.ToLowerInvariant() ?? "generate";
            var configPath = GetOption(args, "--config") ?? Path.Combine(root, "config.json");
            var app = new App(root, configPath);
            return command switch
            {
                "generate" => app.Generate(false),
                "install" => app.Generate(true),
                "check" => app.Check(),
                "help" or "--help" or "-h" => PrintHelp(),
                _ => throw new UserError($"Unknown command: {command}. Run AC8PGMCustomizer help.")
            };
        }
        catch (UserError ex)
        {
            Console.Error.WriteLine($"ERROR: {ex.Message}");
            return 2;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"ERROR: {ex.Message}");
            return 1;
        }
    }

    private static int PrintHelp()
    {
        Console.WriteLine("""
            AC8 PGM Customizer

            Usage:
              AC8PGMCustomizer.exe check [--config <path>]
              AC8PGMCustomizer.exe generate [--config <path>]
              AC8PGMCustomizer.exe install [--config <path>]

            Edit config.json, then run generate to create AC8PGMDirect_P.* in the
            configured output directory. Run install to generate and copy those files
            into an existing AC8 PGM installation. ACE COMBAT 8 must be closed.
            """);
        return 0;
    }

    private static string? GetOption(string[] args, string name)
    {
        for (var i = 0; i < args.Length - 1; i++)
            if (args[i].Equals(name, StringComparison.OrdinalIgnoreCase)) return args[i + 1];
        return null;
    }

    private static string FindRoot()
    {
        foreach (var start in new[] { AppContext.BaseDirectory, Environment.CurrentDirectory })
        {
            var dir = new DirectoryInfo(start);
            while (dir is not null)
            {
                if (File.Exists(Path.Combine(dir.FullName, "data", "retoc.exe")) &&
                    File.Exists(Path.Combine(dir.FullName, "data", "Mappings.usmap"))) return dir.FullName;
                dir = dir.Parent;
            }
        }
        throw new UserError("The data directory was not found. Extract the complete Customizer package.");
    }

    private sealed class App
    {
        private readonly string _root;
        private readonly string _configPath;
        private readonly Config _config;
        private readonly string _game;
        private readonly string _data;
        private readonly string _template;
        private readonly string _retoc;
        private readonly string _mapping;
        private readonly string _output;

        public App(string root, string configPath)
        {
            _root = root;
            _configPath = Path.GetFullPath(configPath, Environment.CurrentDirectory);
            if (!File.Exists(_configPath)) throw new UserError($"Config file not found: {_configPath}");
            _config = JsonSerializer.Deserialize<Config>(File.ReadAllText(_configPath), JsonOptions)
                ?? throw new UserError("The config file is empty or invalid.");
            var configDir = Path.GetDirectoryName(_configPath)!;
            _game = ResolveGamePath(_config.GamePath, configDir);
            _data = Path.Combine(_root, "data");
            _template = Path.Combine(_data, "template");
            _retoc = Path.Combine(_data, "retoc.exe");
            _mapping = Path.Combine(_data, "Mappings.usmap");
            _output = Path.GetFullPath(_config.OutputPath, configDir);
        }

        public int Check()
        {
            RequireInputs();
            var manifest = ReadTemplateManifest();
            ValidateConfig(manifest);
            Console.WriteLine($"[OK] Game: {_game}");
            Console.WriteLine($"[OK] Template assets: {manifest.Assets.Count}");
            Console.WriteLine($"[OK] Output: {_output}");
            Console.WriteLine("[OK] Configuration values are finite and within 0..10");
            return 0;
        }

        public int Generate(bool install)
        {
            if (Process.GetProcessesByName("AceCombat8").Length != 0)
                throw new UserError("Exit ACE COMBAT 8 before generating or installing files.");
            RequireInputs();
            var manifest = ReadTemplateManifest();
            ValidateConfig(manifest);
            var temporary = Path.Combine(Path.GetTempPath(), "AC8PGMCustomizer-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(temporary);
            try
            {
                var input = Path.Combine(temporary, "input");
                var legacy = Path.Combine(temporary, "legacy");
                var generated = Path.Combine(temporary, "generated");
                Directory.CreateDirectory(input);
                Directory.CreateDirectory(generated);
                Console.WriteLine("Copying the validated AC8 PGM resource template...");
                CopyDirectory(Path.Combine(_data, "legacy"), legacy);
                var effective = PatchAssets(legacy, manifest);
                var package = Path.Combine(generated, BaseName + ".utoc");
                Console.WriteLine("Building IoStore override...");
                Run(_retoc, ["to-zen", legacy, package, "--version", "UE5_4"]);
                Run(_retoc, ["verify", package]);
                VerifyRoundTrip(temporary, package, legacy, effective.Select(x => x.Asset));
                WriteManifest(generated, manifest, effective, legacy);
                CopyResult(generated, _output);
                Console.WriteLine($"[OK] Generated: {_output}");
                if (install) InstallResult(_output);
                return 0;
            }
            finally
            {
                if (Directory.Exists(temporary)) Directory.Delete(temporary, true);
            }
        }

        private void RequireInputs()
        {
            RequireFile(Path.Combine(_game, "Game", "Binaries", "Win64", "AceCombat8.exe"), "game executable");
            RequireFile(Path.Combine(_game, "Game", "Content", "Paks", "global.utoc"), "global.utoc");
            RequireFile(Path.Combine(_game, "Game", "Content", "Paks", "global.ucas"), "global.ucas");
            RequireFile(_retoc, "retoc.exe");
            RequireFile(_mapping, "Mappings.usmap");
            RequireFile(Path.Combine(_template, BaseName + ".build.json"), "template build manifest");
            RequireFile(Path.Combine(_data, "legacy", PackageFile(PlayerTablePackage)), "Legacy resource template");
        }

        private TemplateManifest ReadTemplateManifest()
        {
            return JsonSerializer.Deserialize<TemplateManifest>(
                File.ReadAllText(Path.Combine(_template, BaseName + ".build.json")), JsonOptions)
                ?? throw new UserError("The template build manifest is invalid.");
        }

        private void ValidateConfig(TemplateManifest manifest)
        {
            var available = manifest.Assets.GroupBy(x => x.Side, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(x => x.Key, x => x.Select(y => y.Type).ToHashSet(StringComparer.OrdinalIgnoreCase), StringComparer.OrdinalIgnoreCase);
            foreach (var (side, values) in new[] { ("player", _config.Player), ("enemy", _config.Enemy) })
            {
                foreach (var (name, value) in values)
                {
                    if (!available.TryGetValue(side, out var names) || !names.Contains(name))
                        throw new UserError($"Unknown weapon type: {side}.{name}");
                    if (double.IsNaN(value) || double.IsInfinity(value) || value < 0 || value > 10)
                        throw new UserError($"{side}.{name} must be a finite number from 0 to 10.");
                }
            }
        }

        private List<EffectiveAsset> PatchAssets(string legacy, TemplateManifest manifest)
        {
            var mappings = new Usmap(_mapping);
            var cdoNames = ReadCdoNames();
            var playerTable = new SettingsTableEditor(Path.Combine(legacy, PackageFile(PlayerTablePackage)), mappings, "PLAYER");
            var enemyTable = new SettingsTableEditor(Path.Combine(legacy, PackageFile(EnemyTablePackage)), mappings, "ENEMY");
            var result = new List<EffectiveAsset>();
            var index = 0;
            foreach (var item in manifest.Assets)
            {
                var configured = item.Side.Equals("player", StringComparison.OrdinalIgnoreCase) ? _config.Player : _config.Enemy;
                var value = (float)(configured.TryGetValue(item.Type, out var custom) ? custom : item.Value);
                var path = Path.Combine(legacy, PackageFile(item.Asset));
                var settings = item.Side.Equals("player", StringComparison.OrdinalIgnoreCase) ? playerTable : enemyTable;
                if (!cdoNames.TryGetValue(item.Asset, out var cdoName))
                    throw new UserError($"CDO mapping not found for template asset: {item.Asset}");
                PatchBlueprint(path, mappings, value, settings, cdoName);
                result.Add(new EffectiveAsset(item.Side, item.Type, value, item.Asset));
                Console.WriteLine($"[{++index}/{manifest.Assets.Count}] {item.Side}.{item.Type} = {value.ToString("G9", CultureInfo.InvariantCulture)}");
            }
            if (_config.Player.TryGetValue("qaam", out var playerQaam)) playerTable.SetExistingRow("qaam_ON", (float)playerQaam);
            enemyTable.SetMatchingRows(_config.Enemy);
            playerTable.Write(Path.Combine(legacy, PackageFile(PlayerTablePackage)));
            enemyTable.Write(Path.Combine(legacy, PackageFile(EnemyTablePackage)));
            return result;
        }

        private Dictionary<string, string> ReadCdoNames()
        {
            var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (var file in new[] { "weapon_classes.lua", "npc_weapons.lua" })
            {
                var path = Path.Combine(_data, file);
                RequireFile(path, file);
                foreach (Match match in Regex.Matches(File.ReadAllText(path), "\"(?<package>/Game/[^\".]+)\\.(?<cdo>Default__[^\"]+)\""))
                    result[match.Groups["package"].Value] = match.Groups["cdo"].Value;
            }
            return result;
        }

        private static void PatchBlueprint(string path, Usmap mappings, float value, SettingsTableEditor settings, string cdoName)
        {
            RequireFile(path, "template asset");
            var asset = new UAsset(path, EngineVersion.VER_UE5_4, mappings);
            var cdo = asset.Exports.OfType<NormalExport>().SingleOrDefault(x => x.ObjectName.ToString().Equals(cdoName, StringComparison.OrdinalIgnoreCase))
                ?? throw new UserError($"CDO not found in {path}: {cdoName}. Exports: " +
                    string.Join(", ", asset.Exports.Select(x => $"{x.GetType().Name}:{x.ObjectName}")));
            if (cdo[PropertyName] is not FloatPropertyData homing)
                throw new UserError($"{PropertyName} is missing or not a float in {path}");
            homing.Value = value;
            if (cdo["WeaponSettingsId_DifficultyMap"] is MapPropertyData map)
                foreach (var entry in map.Value)
                    if (entry.Value is NamePropertyData row) settings.SetReferencedRow(row.Value.ToString(), value);
            asset.ResolveAncestries();
            asset.Write(path);
            var check = new UAsset(path, EngineVersion.VER_UE5_4, mappings);
            var checkCdo = check.Exports.OfType<NormalExport>().Single(x => x.ObjectName.ToString().Equals(cdoName, StringComparison.OrdinalIgnoreCase));
            var actual = (checkCdo[PropertyName] as FloatPropertyData)?.Value;
            if (actual is null || Math.Abs(actual.Value - value) > 0.00001f)
                throw new UserError($"Asset read-back failed: {path}");
        }

        private void VerifyRoundTrip(string temporary, string package, string expectedRoot, IEnumerable<string> packages)
        {
            var input = Path.Combine(temporary, "verify-input");
            var output = Path.Combine(temporary, "verify-output");
            Directory.CreateDirectory(input);
            Directory.CreateDirectory(output);
            foreach (var ext in new[] { ".utoc", ".ucas", ".pak" })
                File.Copy(Path.ChangeExtension(package, ext), Path.Combine(input, BaseName + ext), true);
            var paks = Path.Combine(_game, "Game", "Content", "Paks");
            foreach (var ext in new[] { ".utoc", ".ucas" })
                File.Copy(Path.Combine(paks, "global" + ext), Path.Combine(input, "global" + ext), true);
            Run(_retoc, ["to-legacy", "--version", "UE5_4", "--no-shaders", input, output]);
            var all = packages.Append(PlayerTablePackage).Append(EnemyTablePackage).Distinct(StringComparer.OrdinalIgnoreCase);
            foreach (var item in all)
            {
                var relative = Path.ChangeExtension(PackageFile(item), ".uexp");
                if (!FileHash(Path.Combine(expectedRoot, relative)).Equals(FileHash(Path.Combine(output, relative)), StringComparison.OrdinalIgnoreCase))
                    throw new UserError($"IoStore round-trip verification failed: {item}");
            }
            Console.WriteLine("[OK] IoStore round-trip verification passed.");
        }

        private static void WriteManifest(string generated, TemplateManifest template, List<EffectiveAsset> assets, string legacy)
        {
            var packages = assets.Select(x => x.Asset).Append(PlayerTablePackage).Append(EnemyTablePackage).Distinct(StringComparer.OrdinalIgnoreCase);
            var node = new JsonObject
            {
                ["tool"] = "AC8PGMCustomizer",
                ["property"] = PropertyName,
                ["config"] = "config.json",
                ["package"] = BaseName + ".utoc",
                ["createdUtc"] = DateTimeOffset.UtcNow,
                ["templateCreatedUtc"] = template.CreatedUtc,
                ["assets"] = JsonSerializer.SerializeToNode(assets, JsonOptions),
                ["payloads"] = new JsonArray(packages.Select(x => (JsonNode)new JsonObject
                {
                    ["asset"] = x,
                    ["payloadSha256"] = FileHash(Path.ChangeExtension(Path.Combine(legacy, PackageFile(x)), ".uexp"))
                }).ToArray())
            };
            File.WriteAllText(Path.Combine(generated, BaseName + ".build.json"), node.ToJsonString(JsonOptions), new UTF8Encoding(false));
        }

        private static void CopyResult(string source, string destination)
        {
            Directory.CreateDirectory(destination);
            foreach (var ext in new[] { ".utoc", ".ucas", ".pak", ".build.json" })
            {
                var from = Path.Combine(source, BaseName + ext);
                var to = Path.Combine(destination, BaseName + ext);
                var temporary = to + ".generating";
                File.Copy(from, temporary, true);
                File.Move(temporary, to, true);
            }
        }

        private void InstallResult(string output)
        {
            var destination = Path.Combine(_game, "Game", "Binaries", "Win64", "ue4ss", "Mods", "IoStoreLoaderMod", "AC8PGMDirect");
            if (!Directory.Exists(Path.GetDirectoryName(destination)) ||
                !File.Exists(Path.Combine(Path.GetDirectoryName(destination)!, "dlls", "main.dll")))
                throw new UserError("AC8 PGM is not installed. Install the base mod before using the install command.");
            Directory.CreateDirectory(destination);
            CopyResult(output, destination);
            Console.WriteLine($"[OK] Installed customized files: {destination}");
        }
    }

    private sealed class SettingsTableEditor
    {
        private readonly UAsset _asset;
        private readonly DataTableExport _table;
        private readonly Usmap _mappings;
        private readonly Dictionary<string, float> _updates = new(StringComparer.OrdinalIgnoreCase);

        public SettingsTableEditor(string path, Usmap mappings, string label)
        {
            RequireFile(path, label + " settings table");
            _mappings = mappings;
            _asset = new UAsset(path, EngineVersion.VER_UE5_4, mappings);
            _table = _asset.Exports.OfType<DataTableExport>().SingleOrDefault()
                ?? throw new UserError($"{label} settings asset is not a data table.");
        }

        public void SetReferencedRow(string name, float value)
        {
            if (!name.StartsWith("AC8PN_", StringComparison.OrdinalIgnoreCase) &&
                !name.StartsWith("AC8PGM_", StringComparison.OrdinalIgnoreCase))
                throw new UserError($"Unexpected non-template settings row: {name}");
            SetExistingRow(name, value);
        }

        public void SetExistingRow(string name, float value)
        {
            if (_updates.TryGetValue(name, out var prior) && Math.Abs(prior - value) > 0.00001f)
                throw new UserError($"Conflicting values for settings row {name}: {prior} and {value}");
            var row = _table.Table.Data.SingleOrDefault(x => x.Name.ToString().Equals(name, StringComparison.OrdinalIgnoreCase))
                ?? throw new UserError($"Settings row not found: {name}");
            if (row[PropertyName] is not FloatPropertyData homing)
                throw new UserError($"Settings row {name} has no float {PropertyName}");
            homing.Value = value;
            _updates[name] = value;
        }

        public void SetMatchingRows(IReadOnlyDictionary<string, double> configured)
        {
            foreach (var row in _table.Table.Data)
                foreach (var key in configured.Keys.OrderByDescending(x => x.Length))
                {
                    var token = key.Equals("msl", StringComparison.OrdinalIgnoreCase) ? "missile" : key;
                    if (!row.Name.ToString().Contains(token, StringComparison.OrdinalIgnoreCase)) continue;
                    SetExistingRow(row.Name.ToString(), (float)configured[key]);
                    break;
                }
        }

        public void Write(string path)
        {
            _asset.ResolveAncestries();
            _asset.Write(path);
            var check = new UAsset(path, EngineVersion.VER_UE5_4, _mappings);
            var table = check.Exports.OfType<DataTableExport>().Single();
            foreach (var (name, expected) in _updates)
            {
                var row = table.Table.Data.Single(x => x.Name.ToString().Equals(name, StringComparison.OrdinalIgnoreCase));
                var actual = (row[PropertyName] as FloatPropertyData)?.Value;
                if (actual is null || Math.Abs(actual.Value - expected) > 0.00001f)
                    throw new UserError($"Settings table read-back failed: {name}");
            }
        }
    }

    private static string ResolveGamePath(string configured, string configDirectory)
    {
        var candidates = new List<string>();
        if (!string.IsNullOrWhiteSpace(configured)) candidates.Add(Path.GetFullPath(configured, configDirectory));
        foreach (var key in new[] { @"HKEY_CURRENT_USER\Software\Valve\Steam", @"HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Valve\Steam" })
        {
            foreach (var property in new[] { "SteamPath", "InstallPath" })
            {
                var steam = Microsoft.Win32.Registry.GetValue(key, property, null) as string;
                if (string.IsNullOrWhiteSpace(steam)) continue;
                candidates.Add(Path.Combine(steam, "steamapps", "common", "ACE COMBAT 8"));
                var vdf = Path.Combine(steam, "steamapps", "libraryfolders.vdf");
                if (!File.Exists(vdf)) continue;
                foreach (Match match in Regex.Matches(File.ReadAllText(vdf), "\"path\"\\s+\"([^\"]+)\""))
                    candidates.Add(Path.Combine(match.Groups[1].Value.Replace("\\\\", "\\"), "steamapps", "common", "ACE COMBAT 8"));
            }
        }
        return candidates.Distinct(StringComparer.OrdinalIgnoreCase).FirstOrDefault(x => File.Exists(Path.Combine(x, "Game", "Binaries", "Win64", "AceCombat8.exe")))
            ?? throw new UserError("ACE COMBAT 8 was not found. Set gamePath in config.json.");
    }

    private static string PackageFile(string package)
    {
        const string prefix = "/Game/";
        if (!package.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) throw new UserError("Unsupported package path: " + package);
        return Path.Combine("Live", "Content", package[prefix.Length..].Replace('/', Path.DirectorySeparatorChar) + ".uasset");
    }

    private static void Run(string executable, IReadOnlyCollection<string> arguments)
    {
        var info = new ProcessStartInfo(executable) { UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true, CreateNoWindow = true };
        foreach (var argument in arguments) info.ArgumentList.Add(argument);
        using var process = Process.Start(info) ?? throw new UserError("Failed to start: " + executable);
        var stdout = process.StandardOutput.ReadToEndAsync();
        var stderr = process.StandardError.ReadToEndAsync();
        process.WaitForExit();
        Task.WaitAll(stdout, stderr);
        if (!string.IsNullOrWhiteSpace(stdout.Result)) Console.Write(stdout.Result);
        if (!string.IsNullOrWhiteSpace(stderr.Result)) Console.Error.Write(stderr.Result);
        if (process.ExitCode != 0) throw new UserError($"{Path.GetFileName(executable)} failed with exit code {process.ExitCode}.");
    }

    private static void RequireFile(string path, string label)
    {
        if (!File.Exists(path)) throw new UserError($"Missing {label}: {path}");
    }

    private static void CopyDirectory(string source, string destination)
    {
        if (!Directory.Exists(source)) throw new UserError("Missing template directory: " + source);
        Directory.CreateDirectory(destination);
        foreach (var directory in Directory.EnumerateDirectories(source, "*", SearchOption.AllDirectories))
            Directory.CreateDirectory(Path.Combine(destination, Path.GetRelativePath(source, directory)));
        foreach (var file in Directory.EnumerateFiles(source, "*", SearchOption.AllDirectories))
            File.Copy(file, Path.Combine(destination, Path.GetRelativePath(source, file)), true);
    }

    private static string FileHash(string path)
    {
        RequireFile(path, "verification file");
        using var stream = File.OpenRead(path);
        return Convert.ToHexString(SHA256.HashData(stream));
    }

    private sealed class Config
    {
        public string GamePath { get; init; } = "";
        public string OutputPath { get; init; } = "output";
        public Dictionary<string, double> Player { get; init; } = new(StringComparer.OrdinalIgnoreCase);
        public Dictionary<string, double> Enemy { get; init; } = new(StringComparer.OrdinalIgnoreCase);
    }

    private sealed class TemplateManifest
    {
        public string? CreatedUtc { get; init; }
        public List<TemplateAsset> Assets { get; init; } = [];
    }

    private sealed record TemplateAsset(string Side, string Type, double Value, string Asset);
    private sealed record EffectiveAsset(string Side, string Type, float Value, string Asset);
    private sealed class UserError(string message) : Exception(message);
}
