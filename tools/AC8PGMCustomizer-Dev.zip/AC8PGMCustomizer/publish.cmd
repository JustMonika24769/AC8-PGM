@echo off
setlocal
dotnet restore
if errorlevel 1 exit /b 1
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o dist --no-restore
if errorlevel 1 exit /b %errorlevel%
xcopy /E /I /Y data dist\data >nul
if errorlevel 1 exit /b %errorlevel%
copy /Y config.json dist\config.json >nul
copy /Y README.md dist\README.md >nul
copy /Y THIRD_PARTY.md dist\THIRD_PARTY.md >nul
del /Q dist\*.pdb dist\*.xml 2>nul
exit /b 0
