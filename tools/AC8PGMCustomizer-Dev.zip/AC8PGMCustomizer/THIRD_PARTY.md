# Third-Party Components

- UAssetAPI 2.0.0, MIT License: <https://github.com/atenfyr/UAssetAPI>
- retoc 0.1.5, MIT License: <https://github.com/trumank/retoc>
- Newtonsoft.Json and ZstdSharp.Port are transitive UAssetAPI dependencies.

The original license files are included in the source tree or the release package. The customizer
does not contain ACE COMBAT 8 executable files, AES keys, or Oodle libraries.
