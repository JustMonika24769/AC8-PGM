# AC8 PGM Customizer

用于为 AC8 PGM 修改比例制导参数并重新生成 IoStore 覆盖文件。仅支持
ACE COMBAT 8 `1.1.2.0` 和单机战役。

## 使用

1. 完整解压本工具，不要只取出 EXE。
2. 用文本编辑器打开 `config.json`，修改 `player` 和 `enemy` 中的数值。
3. 退出游戏。
4. 在当前目录打开终端并运行：

   ```text
   AC8PGMCustomizer.exe check
   AC8PGMCustomizer.exe generate
   ```

5. 生成文件位于 `output`：

   ```text
   AC8PGMDirect_P.utoc
   AC8PGMDirect_P.ucas
   AC8PGMDirect_P.pak
   AC8PGMDirect_P.build.json
   ```

如果基础 AC8 PGM 已经安装，可以直接运行：

```text
AC8PGMCustomizer.exe install
```

该命令会先生成并完整验证，再覆盖基础模组的四个资源文件。它不会修改游戏原始
`pakchunk0-Windows.*`。

## 配置

- `gamePath` 留空时自动查找 Steam 游戏目录；自动查找失败时填写完整路径。
- `outputPath` 是生成目录，相对于 `config.json` 所在目录解析。
- `player` 是玩家导弹，`enemy` 是敌方导弹。
- 数值必须是 `0` 到 `10` 的有限数字。
- 删除某一项会保留模板中的默认值。

较高数值并不保证更自然或更稳定。建议逐步调整并在离线战役中测试。

本工具不能用于多人、联网活动或排行榜。使用前应卸载其他比例制导模组，并按基础
模组文档使用离线 EAC 启动配置。遇到问题请查看基础模组和开发者包中的详细文档。
