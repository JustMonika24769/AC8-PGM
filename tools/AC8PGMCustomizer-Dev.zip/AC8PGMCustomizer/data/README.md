# Customizer build data

Populate this directory from the verified `AC8AssetPatcher` build before publishing:

- `Mappings.usmap`
- `retoc.exe`
- `weapon_classes.lua` and `npc_weapons.lua`
- `work/build/staged` copied as `legacy`
- `work/build/output/build-manifest.json` copied as
  `template/AC8PGMDirect_P.build.json`

Do not publish AES keys, Oodle, original game containers, or unrelated extracted assets.
